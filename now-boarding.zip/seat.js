/* ===== Seating plan: where you sit + a random scenario for that seat ===== */
(function () {
  var to = new URLSearchParams(location.search).get('to');
  if (!DEST[to]) { location.replace('departures.html'); return; }
  $('backlink').href = 'boarding.html?to=' + to;

  var LET = 'ABCDEF', ROWS = 30, seat = null, scn = null;
  function pickSeat() { return (Math.floor(Math.random() * ROWS) + 1) + LET[Math.floor(Math.random() * 6)]; }
  try { seat = sessionStorage.getItem('seat'); } catch (e) {}
  if (!seat || !/^\d{1,2}[A-F]$/.test(seat)) seat = pickSeat();
  try { sessionStorage.setItem('seat', seat); } catch (e) {}

  function parse(s) { return { r: parseInt(s, 10), c: s.slice(-1) }; }
  function kind(c) { return (c === 'A' || c === 'F') ? 'window' : (c === 'B' || c === 'E') ? 'middle' : 'aisle'; }

  /* e = emoji, t = title, x = story, fx = who sits around you, wc = the bathroom trek */
  var SC = {
    window: [
      { e: '🪟', t: 'Window seat', x: 'The view is unreal. Then you need the bathroom, and both neighbours are fast asleep. Time to climb.', fx: { block: '😴' }, wc: 1 },
      { e: '☁️', t: 'Cloud watching', x: 'Golden hour above the clouds with your playlist on. Best seat on the plane.', fx: {} },
      { e: '🥤', t: 'Tray table trouble', x: 'Your drink slides into the wall just as the plane tilts. You have two napkins left.', fx: {} }
    ],
    middle: [
      { e: '😴', t: 'The shoulder sandwich', x: 'Both neighbours fall asleep on your shoulders. You cannot move. You cannot scratch your nose.', fx: { l: '😴', r: '😴' } },
      { e: '💪', t: 'Armrest diplomacy', x: 'Both armrests are taken. You become an expert in elbow negotiations.', fx: { l: '😒', r: '😒' } },
      { e: '🍿', t: 'The snack relay', x: 'You pass everyone’s snacks, trays and headphones for the entire flight.', fx: { l: '🙏', r: '🙏' } }
    ],
    aisle: [
      { e: '🛒', t: 'Trolley hit number six', x: 'The snack cart clips your elbow again. Your elbow has stopped counting.', fx: {} },
      { e: '🚶', t: 'Stand up, again', x: 'Your whole row needs the bathroom, one at a time. You are the doorman now.', fx: { block: '🚶' } },
      { e: '🦵', t: 'Legroom privileges', x: 'You stretch one leg into the aisle. Nobody notices. It’s glorious.', fx: {} }
    ],
    front: [{ e: '👶', t: 'The kicker behind you', x: 'A small child behind you kicks your chair for the entire flight. Thump. Thump. Thump.', fx: { back: '👶' } }],
    rear: [{ e: '🚻', t: 'Lavatory neighbour', x: 'You sit next to the bathrooms. The door slams every three minutes, and you hear everything.', fx: {}, wc: 1 }]
  };
  function pool() {
    var s = parse(seat), p = SC[kind(s.c)].slice();
    if (s.r <= 8) p = p.concat(SC.front, SC.front);
    if (s.r >= 26) p = p.concat(SC.rear, SC.rear);
    return p;
  }
  function roll() { var p = pool(), n; do { n = p[Math.floor(Math.random() * p.length)]; } while (p.length > 1 && n === scn); scn = n; }

  function marks() {
    var m = {}, s = parse(seat), fx = scn.fx || {}, i = LET.indexOf(s.c), blk = i < 3 ? [0, 1, 2] : [3, 4, 5];
    function put(r, c, e) { if (c >= 0 && c < 6 && r >= 1 && r <= ROWS) m[r + LET[c]] = e; }
    if (fx.l) put(s.r, i - 1, fx.l);
    if (fx.r) put(s.r, i + 1, fx.r);
    if (fx.block) blk.forEach(function (b) { if (b !== i) put(s.r, b, fx.block); });
    if (fx.back) put(s.r + 1, i, fx.back);
    if (fx.front) put(s.r - 1, i, fx.front);
    return m;
  }

  function plan() {
    var m = marks(), h = '<div class="nose">✈</div>';
    for (var r = 1; r <= ROWS; r++) {
      h += '<div class="rw' + (r === 12 || r === 13 ? ' ex' : '') + '">';
      for (var i = 0; i < 6; i++) {
        if (i === 3) h += '<b class="rn">' + r + '</b>';
        var id = r + LET[i], me = id === seat, cls = 'st' + (me ? ' me' : m[id] ? ' mk' : (((r * 7 + i * 13) % 5) ? ' occ' : ' free'));
        h += '<div class="' + cls + '" id="s' + id + '">' + (me ? 'YOU' : (m[id] || '')) + '</div>';
      }
      h += '</div>';
    }
    h += '<div class="wc' + (scn.wc ? ' hot' : '') + '"><span>WC</span><span>WC</span></div>';
    $('cabin').innerHTML = h;
  }
  function card() {
    var s = parse(seat);
    $('em').textContent = scn.e; $('tt').textContent = scn.t; $('tx').textContent = scn.x;
    $('badge').textContent = kind(s.c).toUpperCase() + ' SEAT · ' + seat;
    $('go').textContent = 'Continue to ' + DEST[to][0] + ' →';
    var c = $('card'); c.classList.remove('swap'); void c.offsetWidth; c.classList.add('swap');
  }
  function focus() { var c = $('cabin'), me = $('s' + seat); if (me) c.scrollTo({ top: me.offsetTop - c.clientHeight / 2 + 20, behavior: 'smooth' }); }
  function refresh(f) { roll(); plan(); card(); if (f) focus(); }

  $('again').onclick = function () { refresh(false); };
  $('newseat').onclick = function () { seat = pickSeat(); try { sessionStorage.setItem('seat', seat); } catch (e) {} refresh(true); };
  $('go').onclick = function () { takeoff(to + '.html'); };
  refresh(false); setTimeout(focus, 350);
})();
